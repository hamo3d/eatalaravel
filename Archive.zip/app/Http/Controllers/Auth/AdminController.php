<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminController extends Controller
{

    public function register(Request $request)
    {
        $validatore = Validator($request->all(), [
            'name' => 'required|string',
            'email' => 'required|email|unique:admins,email',
            'phone' => 'required|unique:admins,phone'
        ]);

        if (!$validatore->fails()) {
            $admin = new Admin();
            $admin->name = $request->input('name');
            $admin->email = $request->input('email');
            $admin->phone = $request->input('phone');
            $saved = $admin->save();
            return response()->json(['status' => $saved, 'message' => $saved ? 'register successfuly' : 'Registration filed', 'object' => $admin], $saved ? Response::HTTP_CREATED : Response::HTTP_BAD_REQUEST);
        } else {
            return response()->json(['status' => false, 'message' => $validatore->getMessageBag()->first()], Response::HTTP_BAD_REQUEST);
        }
    }

    public function login(Request $request)
    {
        $validatore = Validator($request->all(), [
            'phone' => 'required|exists:admins,phone',
        ]);
        if (!$validatore->fails()) {
            $admin = Admin::where('phone', '=', $request->input('phone'))->first();
            $token = $admin->createToken('admin-api-token-' . $admin->id);
            $admin->token = $token->accessToken;
            return response()->json(['status' => true, 'object' => $admin]);
        } else {
            return response()->json(['status' => false, 'message' => $validatore->getMessageBag()->first()], Response::HTTP_BAD_REQUEST);

        }
    }

    public function logout(Request $request)
    {
        $admin = $request->user('admin-api');
        $revoked = $admin->token()->revoke();
        return response()->json(['status' => $revoked, 'message' => $revoked ? 'logout successfully' : 'faild logout'], $revoked ? Response::HTTP_OK : Response::HTTP_BAD_REQUEST);
    }
}
